"""Generated Django infrastructure."""

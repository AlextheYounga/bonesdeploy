"""Generated Vue infrastructure."""

"""Generated Next.js infrastructure."""

"""Generated Rails infrastructure."""

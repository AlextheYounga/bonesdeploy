"""Generated SvelteKit infrastructure."""

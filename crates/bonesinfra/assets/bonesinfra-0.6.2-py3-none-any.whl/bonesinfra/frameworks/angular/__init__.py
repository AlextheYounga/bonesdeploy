"""Generated Angular infrastructure."""

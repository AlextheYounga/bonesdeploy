from dataclasses import dataclass
from pathlib import Path


class _TemplatePath:
    def __init__(self, *parts: str):
        self.parts = parts

    def __truediv__(self, part: str) -> "_TemplatePath":
        return _TemplatePath(*self.parts, part)

    def _path(self) -> Path:
        try:
            project = Path.cwd() / "infra" / "templates"
            if project.is_dir():
                return project.joinpath(*self.parts)
        except PermissionError:
            pass
        package = Path(__file__).parent.parent
        if self.parts and self.parts[0] == "shared":
            return package / "assets" / Path(*self.parts[1:])
        if len(self.parts) > 1 and self.parts[0] == "frameworks":
            return package / "frameworks" / self.parts[1] / "templates" / Path(*self.parts[2:])
        return package.joinpath(*self.parts)

    def __fspath__(self) -> str:
        return str(self._path())

    def __str__(self) -> str:
        return str(self._path())

    def __eq__(self, other: object) -> bool:
        return self._path() == other

    def __hash__(self) -> int:
        return hash(self.parts)


TEMPLATES_DIR = _TemplatePath()
ASSETS_DIR = TEMPLATES_DIR / "shared"
SCRIPTS_DIR = ASSETS_DIR / "scripts"

BONESDEPLOY_LOG_ROOT = "/var/log/bonesdeploy"
PATCHES_ROOT = "/var/lib/bonesdeploy/patches"
DEFAULT_PROJECT_ROOT_PARENT = "/srv/sites"
DEFAULT_CONF_ROOT_PARENT = "/srv/conf"
DEFAULT_WEB_ROOT = "public"

ETC_NGINX_SITES_AVAILABLE = "/etc/nginx/sites-available"
ETC_NGINX_SITES_ENABLED = "/etc/nginx/sites-enabled"
ETC_SYSTEMD_SYSTEM = "/etc/systemd/system"
ETC_APPARMOR_D = "/etc/apparmor.d"
ETC_SSL_CERTS = "/etc/ssl/certs"
ETC_SSL_PRIVATE = "/etc/ssl/private"
ETC_SUDOERS_D = "/etc/sudoers.d"
ETC_SSH_SSHD_CONFIG_D = "/etc/ssh/sshd_config.d"

RUNTIME_SOCKET_PARENT = "/run"
NGINX_CONF = "nginx.conf"
INDEX_HTML = "index.html"
RELEASES_DIR = "releases"
SHARED_DIR = "shared"
CURRENT_LINK = "current"
PLACEHOLDER_RELEASE_NAME = "19700101_000000"

NGINX_SOCKET = "nginx.sock"
NGINX_PID = "nginx.pid"
PHP_FPM_SOCKET = "php-fpm.sock"
DEFAULT_NGINX_SITE = "default"
BONESDEPLOY_NGINX_DEFAULT_DENY_SITE = "00-bonesdeploy-default-deny.conf"
BONESDEPLOY_NGINX_DEFAULT_DENY_CERT = "bonesdeploy-default-deny.crt"
BONESDEPLOY_NGINX_DEFAULT_DENY_KEY = "bonesdeploy-default-deny.key"
BONESDEPLOY_NGINX_CLOUDFLARED_SITE = "bonesdeploy-cloudflared-{project}.conf"

BONESREMOTE_CONFIG_DIR = "/root/.config/bonesremote"
BONESREMOTE_SITES_DIR = "sites"
BONESREMOTE_SITE_ROOT = f"{BONESREMOTE_CONFIG_DIR}/{BONESREMOTE_SITES_DIR}"
BACKUPS_ROOT = "/var/lib/bonesdeploy/backups"
BORG_PASSPHRASE_FILE = ".borg_passphrase"  # noqa: S105 - filename, not a secret

BONESREMOTE_BINARY = "bonesremote"

USR_LOCAL_BIN = "/usr/local/bin"
APPARMOR_ENABLED_PARAM = "/sys/module/apparmor/parameters/enabled"
APPARMOR_PROFILES = "/sys/kernel/security/apparmor/profiles"


def _parent_or_default(path: str, fallback: str) -> str:
    parent = str(Path(path).parent)
    return fallback if parent == "." else parent


@dataclass
class DeploymentPaths:
    project_name: str
    site_nginx_config: str
    site_root: str
    conf_root: str
    project_root: str
    project_root_parent: str
    releases: str
    shared: str
    shared_env: str
    current: str
    current_web_root: str
    placeholder_release: str
    placeholder_web_root: str
    placeholder_index: str
    nginx_site_available: str
    nginx_site_enabled: str
    nginx_default_deny_site_available: str
    nginx_default_deny_site_enabled: str
    nginx_default_deny_ssl_certificate: str
    nginx_default_deny_ssl_certificate_key: str
    nginx_default_site_enabled: str
    nginx_cloudflared_site_available: str
    nginx_cloudflared_site_enabled: str
    systemd_site_nginx_service: str
    systemd_cloudflared_service: str
    systemd_site_nginx_requirement: str
    systemd_site_target: str
    systemd_site_target_requires: str
    nginx_apparmor_profile: str
    runtime_socket_dir: str
    runtime_nginx_dir: str
    runtime_nginx_socket: str
    runtime_nginx_pid: str
    runtime_php_fpm_socket: str
    site_log_dir: str
    acme_webroot: str
    backup_repository: str
    backup_passphrase_file: str
    backup_cron_file: str
    sudoers_path: str
    usr_local_bin: str
    bonesremote_global_link: str
    apparmor_enabled_param: str
    apparmor_profiles: str

    @classmethod
    def new(
        cls,
        project_name: str,
        project_root: str,
        web_root: str | None = None,
    ) -> "DeploymentPaths":
        if web_root is None:
            web_root = DEFAULT_WEB_ROOT

        placeholder_release = Path(project_root) / RELEASES_DIR / PLACEHOLDER_RELEASE_NAME
        current = Path(project_root) / CURRENT_LINK
        runtime_socket_dir = Path(RUNTIME_SOCKET_PARENT) / project_name
        runtime_nginx_dir = runtime_socket_dir / "nginx"
        conf_root = Path(DEFAULT_CONF_ROOT_PARENT) / project_name

        return cls(
            project_name=project_name,
            site_nginx_config=str(conf_root / NGINX_CONF),
            site_root=str(Path(BONESREMOTE_SITE_ROOT) / project_name),
            conf_root=str(conf_root),
            project_root=project_root,
            project_root_parent=_parent_or_default(project_root, DEFAULT_PROJECT_ROOT_PARENT),
            releases=str(Path(project_root) / RELEASES_DIR),
            shared=str(Path(project_root) / SHARED_DIR),
            shared_env=str(Path(project_root) / SHARED_DIR / ".env"),
            current=str(current),
            current_web_root=str(current / web_root),
            placeholder_release=str(placeholder_release),
            placeholder_web_root=str(placeholder_release / web_root),
            placeholder_index=str(placeholder_release / web_root / INDEX_HTML),
            nginx_site_available=str(Path(ETC_NGINX_SITES_AVAILABLE) / f"{project_name}.conf"),
            nginx_site_enabled=str(Path(ETC_NGINX_SITES_ENABLED) / f"{project_name}.conf"),
            nginx_default_deny_site_available=str(
                Path(ETC_NGINX_SITES_AVAILABLE) / BONESDEPLOY_NGINX_DEFAULT_DENY_SITE
            ),
            nginx_default_deny_site_enabled=str(Path(ETC_NGINX_SITES_ENABLED) / BONESDEPLOY_NGINX_DEFAULT_DENY_SITE),
            nginx_default_deny_ssl_certificate=str(Path(ETC_SSL_CERTS) / BONESDEPLOY_NGINX_DEFAULT_DENY_CERT),
            nginx_default_deny_ssl_certificate_key=str(Path(ETC_SSL_PRIVATE) / BONESDEPLOY_NGINX_DEFAULT_DENY_KEY),
            nginx_default_site_enabled=str(Path(ETC_NGINX_SITES_ENABLED) / DEFAULT_NGINX_SITE),
            nginx_cloudflared_site_available=str(
                Path(ETC_NGINX_SITES_AVAILABLE) / BONESDEPLOY_NGINX_CLOUDFLARED_SITE.format(project=project_name)
            ),
            nginx_cloudflared_site_enabled=str(
                Path(ETC_NGINX_SITES_ENABLED) / BONESDEPLOY_NGINX_CLOUDFLARED_SITE.format(project=project_name)
            ),
            systemd_site_nginx_service=str(Path(ETC_SYSTEMD_SYSTEM) / f"{project_name}-nginx.service"),
            systemd_cloudflared_service=str(Path(ETC_SYSTEMD_SYSTEM) / f"{project_name}-cloudflared.service"),
            systemd_site_nginx_requirement=str(
                Path(ETC_SYSTEMD_SYSTEM) / f"{project_name}.target.requires/{project_name}-nginx.service"
            ),
            systemd_site_target=str(Path(ETC_SYSTEMD_SYSTEM) / f"{project_name}.target"),
            systemd_site_target_requires=str(Path(ETC_SYSTEMD_SYSTEM) / f"{project_name}.target.requires"),
            nginx_apparmor_profile=str(Path(ETC_APPARMOR_D) / f"bonesdeploy-{project_name}-nginx"),
            runtime_socket_dir=str(runtime_socket_dir),
            runtime_nginx_dir=str(runtime_nginx_dir),
            runtime_nginx_socket=str(runtime_nginx_dir / NGINX_SOCKET),
            runtime_nginx_pid=str(runtime_nginx_dir / NGINX_PID),
            runtime_php_fpm_socket=str(runtime_socket_dir / PHP_FPM_SOCKET),
            site_log_dir=f"/var/log/bonesdeploy/{project_name}",
            acme_webroot=f"/var/www/{project_name}",
            backup_repository=str(Path(BACKUPS_ROOT) / f"{project_name}.borg"),
            backup_passphrase_file=str(Path(BONESREMOTE_SITE_ROOT) / project_name / BORG_PASSPHRASE_FILE),
            backup_cron_file=f"/etc/cron.d/bonesdeploy-{project_name}-backup",
            sudoers_path=str(Path(ETC_SUDOERS_D) / "bonesdeploy"),
            usr_local_bin=USR_LOCAL_BIN,
            bonesremote_global_link=str(Path(USR_LOCAL_BIN) / BONESREMOTE_BINARY),
            apparmor_enabled_param=APPARMOR_ENABLED_PARAM,
            apparmor_profiles=APPARMOR_PROFILES,
        )

    def systemd_service(self, name: str) -> str:
        return str(Path(ETC_SYSTEMD_SYSTEM) / f"{self.project_name}-{name}.service")

    def systemd_service_requirement(self, name: str) -> str:
        return str(Path(self.systemd_site_target_requires) / f"{self.project_name}-{name}.service")

    def apparmor_profile(self, name: str) -> str:
        return str(Path(ETC_APPARMOR_D) / f"bonesdeploy-{self.project_name}-{name}")

    def runtime_service_dir(self, name: str) -> str:
        return str(Path(self.runtime_socket_dir) / name)

    def runtime_service_socket(self, name: str) -> str:
        return str(Path(self.runtime_service_dir(name)) / f"{name}.sock")

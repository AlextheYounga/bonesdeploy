from __future__ import annotations

# The parser import is intentionally lazy to keep domain dataclasses importable.
# ruff: noqa: PLC0415
from dataclasses import dataclass, field
from typing import Any

from bonesinfra.config.paths import DeploymentPaths

DEPLOY_USER = "deploy"
DEFAULT_NODE_VERSION = "24.19.0"


@dataclass
class DeployContext:
    server: ServerContext
    app: AppConfig
    runtime: RuntimeConfig
    backup: BackupConfig
    template: str = "custom"

    @classmethod
    def from_request(cls, body):
        from bonesinfra.config.request import parse_site

        return parse_site(body)

    @property
    def paths(self) -> DeploymentPaths:
        try:
            return self._paths
        except AttributeError:
            pass
        self._paths = DeploymentPaths.new(
            self.app.project_name,
            self.app.project_root,
            self.runtime.web_root,
        )
        return self._paths

    @property
    def paths_dict(self) -> dict[str, Any]:
        return self.paths.__dict__


def template_data(ctx: DeployContext, *, paths: dict[str, Any] | None = None, **extra: Any) -> dict[str, Any]:
    """Build flat template context from DeployContext for Jinja2 template rendering."""
    if paths is None:
        paths = ctx.paths_dict

    data: dict[str, Any] = {
        "project_name": ctx.app.project_name,
        "project_root": paths["project_root"],
        "web_root": ctx.runtime.web_root,
        "node_version": ctx.runtime.node_version,
        "template": ctx.template,
        "deploy_user": DEPLOY_USER,
        "runtime_user": ctx.runtime.runtime_user,
        "runtime_group": ctx.runtime.runtime_group,
        "runtime_backend": ctx.runtime.backend,
        "project_root_parent": paths["project_root_parent"],
        "ssh_port": int(ctx.server.port),
        "paths": paths,
        "ssl_domain": ctx.app.dns.domain,
        "ssl_email": ctx.app.dns.email,
    }

    for key, value in ctx.runtime.data.items():
        if key not in data:
            data[key] = value

    data.update(extra)
    return data


@dataclass
class AppConfig:
    project_name: str
    project_root: str
    dns: DnsConfig


@dataclass
class ServerContext:
    ssh_user: str
    host: str
    port: str

    @classmethod
    def from_request(cls, body):
        from bonesinfra.config.request import parse_request

        return parse_request(body, server_only=True)


@dataclass
class DnsConfig:
    domain: str
    email: str


@dataclass
class RuntimeConfig:
    backend: str
    web_root: str
    runtime_user: str
    runtime_group: str
    compose_port: int | None = None
    compose_wait_timeout: int = 120
    data: dict[str, Any] = field(default_factory=dict)
    node_version: str = DEFAULT_NODE_VERSION


@dataclass(frozen=True)
class BackupConfig:
    """Scheduled Borg backup settings from the provisioning request.

    An empty passphrase means backups are unconfigured and provisioning keeps
    the site's previous behavior.
    """

    schedule: str
    retention_days: int
    passphrase: str

    @property
    def configured(self) -> bool:
        return bool(self.passphrase)

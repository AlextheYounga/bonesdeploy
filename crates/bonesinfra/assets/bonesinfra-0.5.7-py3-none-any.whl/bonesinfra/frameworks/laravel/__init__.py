"""Generated Laravel infrastructure."""

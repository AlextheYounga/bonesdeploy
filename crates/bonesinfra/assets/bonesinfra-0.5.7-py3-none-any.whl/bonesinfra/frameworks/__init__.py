"""Canonical framework infrastructure packages."""

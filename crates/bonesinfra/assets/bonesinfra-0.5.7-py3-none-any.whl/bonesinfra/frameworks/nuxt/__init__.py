"""Generated Nuxt infrastructure."""
